document.getElementById("changeToRed").addEventListener("click", function() {
    document.documentElement.style.setProperty("--dominocolor", "firebrick");
});
document.getElementById("changeToYellow").addEventListener("click", function() {
    document.documentElement.style.setProperty("--dominocolor", "goldenrod");
});
document.getElementById("changeToGreen").addEventListener("click", function() {
    document.documentElement.style.setProperty("--dominocolor", "green");
});
document.getElementById("changeToBlue").addEventListener("click", function() {
    document.documentElement.style.setProperty("--dominocolor", "dodgerblue");
});
document.getElementById("changeToViolet").addEventListener("click", function() {
    document.documentElement.style.setProperty("--dominocolor", "mediumorchid");
});